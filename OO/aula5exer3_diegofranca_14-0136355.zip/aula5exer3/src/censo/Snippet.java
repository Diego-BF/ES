package censo;

public class Snippet
{
	public static void main(String[] args)
	{
		/home/diego/git/ES/OO/aula5exer3/src/censo/Leitor.java
		/home/diego/git/ES/OO/aula5exer3/src/censo/Pessoa.java
		/home/diego/git/ES/OO/aula5exer3/src/censo/Servicos.java
		/home/diego/git/ES/OO/aula5exer3/src/censo/Validador.java
	}
}

