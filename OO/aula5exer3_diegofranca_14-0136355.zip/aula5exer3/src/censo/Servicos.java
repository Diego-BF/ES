package censo;

public class Servicos
{
	public static void limparConsole(int linhas)
	{
		for(int aux = 0; aux < linhas; ++aux)
		{
			System.out.println();
		}
	}
}
