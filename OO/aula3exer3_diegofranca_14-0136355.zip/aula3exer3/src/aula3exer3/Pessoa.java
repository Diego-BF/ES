package aula3exer3;

public class Pessoa {
	String nome;
	int idade;
	float altura;
}
