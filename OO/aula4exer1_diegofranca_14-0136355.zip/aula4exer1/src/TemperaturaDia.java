public class TemperaturaDia 
{
	private float temperatura;
	
	TemperaturaDia(float temperatura)
	{
		this.temperatura = temperatura;
	}
	
	public float getTemperatura() {
		return temperatura;
	}
}